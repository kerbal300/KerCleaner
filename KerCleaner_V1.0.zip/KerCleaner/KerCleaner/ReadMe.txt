Thank you for downloading KerCleaner!

How to open:
- Extract file before running the EXE file.
- Make sure you have Visual Studio Installed. If you don't have it installed, Then go to "vs-setup" file.
- Open the EXE file.

Your done! You can create a shortcut for it!
Please remember, Do not remove the EXE file from the file or else it will break.

This app current version is V1.0