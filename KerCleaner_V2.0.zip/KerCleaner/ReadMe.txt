Thank you for downloading KerCleaner!

How to open:
- Extract file before running the EXE file in "KerCleaner".
- Make sure you have Visual Studio .NET Installed. If you don't have it installed, Then go to "vs-setup" and download x64 bit 
or x86 bit (x32 bit) Depends on your computer bit type, Once you press one of them, It will take you to a website that will 
automatically download the file for you, Don't worry, This website is officially made by Microsoft.
- Open the EXE file in "KerCleaner".

Your done! You can create a shortcut for it!
Please remember, Do not remove the EXE file from the file or else it will break.

This app current version is V2.0